/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50515
Source Host           : localhost:3306
Source Database       : gym_management

Target Server Type    : MYSQL
Target Server Version : 50515
File Encoding         : 65001

Date: 2025-05-05 23:04:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `appointment`
-- ----------------------------
DROP TABLE IF EXISTS `appointment`;
CREATE TABLE `appointment` (
  `AppointmentID` int(11) NOT NULL AUTO_INCREMENT,
  `MemberID` int(11) DEFAULT NULL,
  `CourseID` int(11) DEFAULT NULL,
  `AppointmentDate` datetime DEFAULT NULL,
  `Status` varchar(20) NOT NULL,
  PRIMARY KEY (`AppointmentID`),
  KEY `MemberID` (`MemberID`),
  KEY `CourseID` (`CourseID`),
  CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`MemberID`) REFERENCES `member` (`MemberID`),
  CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`CourseID`) REFERENCES `course` (`CourseID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of appointment
-- ----------------------------
INSERT INTO `appointment` VALUES ('4', '1', '1', null, 'Cancelled');
INSERT INTO `appointment` VALUES ('5', '1', '1', null, 'Cancelled');
INSERT INTO `appointment` VALUES ('6', '1', '1', null, 'Cancelled');

-- ----------------------------
-- Table structure for `coach`
-- ----------------------------
DROP TABLE IF EXISTS `coach`;
CREATE TABLE `coach` (
  `CoachID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Qualification` text,
  `AvailableTime` text,
  `Status` varchar(20) NOT NULL,
  PRIMARY KEY (`CoachID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of coach
-- ----------------------------
INSERT INTO `coach` VALUES ('1', '李教练', '男', '13800138003', 'coach1@example.com', '国家健身教练认证', '周一至周五 9:00-18:00', 'Active');
INSERT INTO `coach` VALUES ('2', '王教练', '女', '13800138004', 'coach2@example.com', '瑜伽教练认证', '周二至周六 10:00-19:00', 'Active');

-- ----------------------------
-- Table structure for `course`
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `CourseID` int(11) NOT NULL AUTO_INCREMENT,
  `CourseName` varchar(100) NOT NULL,
  `Description` text,
  `CoachID` int(11) DEFAULT NULL,
  `CourseTime` datetime NOT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  `Capacity` int(11) NOT NULL,
  `CurrentEnrollment` int(11) DEFAULT '0',
  PRIMARY KEY (`CourseID`),
  KEY `CoachID` (`CoachID`),
  CONSTRAINT `course_ibfk_1` FOREIGN KEY (`CoachID`) REFERENCES `coach` (`CoachID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('1', '瑜伽基础', '适合初学者的瑜伽课程', '2', '2025-04-28 16:16:00', '瑜伽室A', '88.00', '20', '0');
INSERT INTO `course` VALUES ('2', '力量训练', '专业力量训练课程', '1', '2025-04-30 00:16:17', '健身房B区', '108.00', '15', '0');
INSERT INTO `course` VALUES ('3', '有氧运动', '快乐有氧运动课程', '1', '2025-05-01 00:16:17', '有氧运动室', '78.00', '25', '0');

-- ----------------------------
-- Table structure for `member`
-- ----------------------------
DROP TABLE IF EXISTS `member`;
CREATE TABLE `member` (
  `MemberID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Name` varchar(100) NOT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `BirthDate` date DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `RegistrationDate` date DEFAULT NULL,
  `MembershipLevel` varchar(50) DEFAULT NULL,
  `Status` varchar(20) NOT NULL,
  `EmergencyContact` varchar(100) DEFAULT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  PRIMARY KEY (`MemberID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `member_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of member
-- ----------------------------
INSERT INTO `member` VALUES ('1', '2', '张三', '男', '1990-01-15', '13800138001', 'zhangsan@example.com', '2023-01-01', '黄金会员', 'Active', '李四 13900139001', 'zhangsan', 'member123');
INSERT INTO `member` VALUES ('2', '3', '王五', '女', '1995-05-20', '13800138002', 'wangwu@example.com', '2023-02-01', '白金会员', 'Active', '赵六 13900139002', 'wangwu', 'member123');
INSERT INTO `member` VALUES ('4', null, '章程', '男', '2025-04-30', '17362977951', '3231336289@qq.com', '2025-05-05', '普通会员', 'Active', 'ss', 'ss', '199898Cw');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` varchar(10) NOT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', 'admin123', 'admin');
INSERT INTO `user` VALUES ('2', 'member1', 'member123', 'member');
INSERT INTO `user` VALUES ('3', 'member2', 'member123', 'member');
