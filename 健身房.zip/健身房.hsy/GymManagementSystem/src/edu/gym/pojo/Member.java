package edu.gym.pojo;

import java.util.Date; // Use java.util.Date for simplicity, map to java.sql.Date in DAO

public class Member {
    private int memberId;
    private String name;
    private String gender;
    private Date birthDate; // Use java.util.Date here
    private String phoneNumber;
    private String email;
    private Date registrationDate; // Use java.util.Date here
    private String membershipLevel;
    private String status; // e.g., "Active", "Inactive", "Expired" - Requirement: No Enums
    private String emergencyContact;
    private String username; // 添加用户名字段
    private String password; // 添加密码字段
    // Add other fields corresponding to 'Ϣ' if any

    // Constructors
    public Member() {}

    // Getters and Setters for all fields
    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }

    public String getMembershipLevel() {
        return membershipLevel;
    }

    public void setMembershipLevel(String membershipLevel) {
        this.membershipLevel = membershipLevel;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEmergencyContact() {
        return emergencyContact;
    }

    public void setEmergencyContact(String emergencyContact) {
        this.emergencyContact = emergencyContact;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // toString() for debugging (optional)
    @Override
    public String toString() {
        return "Member [memberId=" + memberId + ", name=" + name + ", status=" + status + "]";
    }
}