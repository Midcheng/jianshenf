package edu.gym.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import edu.gym.helper.DBUtil;
import edu.gym.pojo.Coach;

public class CoachDAO {
    
    // 获取所有教练
    public List<Coach> getAllCoaches() {
        List<Coach> coaches = new ArrayList<>();
        String sql = "SELECT * FROM Coach ORDER BY CoachID";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                Coach coach = new Coach();
                coach.setCoachId(rs.getInt("CoachID"));
                coach.setName(rs.getString("Name"));
                coach.setGender(rs.getString("Gender"));
                coach.setPhoneNumber(rs.getString("PhoneNumber"));
                coach.setEmail(rs.getString("Email"));
                coach.setQualification(rs.getString("Qualification"));
                coach.setStatus(rs.getString("Status"));
                coaches.add(coach);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return coaches;
    }

    // 根据ID获取教练
    public Coach getCoachById(int coachId) {
        String sql = "SELECT * FROM Coach WHERE CoachID = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, coachId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Coach coach = new Coach();
                    coach.setCoachId(rs.getInt("CoachID"));
                    coach.setName(rs.getString("Name"));
                    coach.setGender(rs.getString("Gender"));
                    coach.setPhoneNumber(rs.getString("PhoneNumber"));
                    coach.setEmail(rs.getString("Email"));
                    coach.setQualification(rs.getString("Qualification"));
                    coach.setStatus(rs.getString("Status"));
                    return coach;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // 添加教练
    public boolean addCoach(Coach coach) {
        String sql = "INSERT INTO Coach (Name, Gender, PhoneNumber, Email, Qualification, Status) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, coach.getName());
            pstmt.setString(2, coach.getGender());
            pstmt.setString(3, coach.getPhoneNumber());
            pstmt.setString(4, coach.getEmail());
            pstmt.setString(5, coach.getQualification());
            pstmt.setString(6, coach.getStatus());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 更新教练信息
    public boolean updateCoach(Coach coach) {
        String sql = "UPDATE Coach SET Name = ?, Gender = ?, PhoneNumber = ?, Email = ?, Qualification = ?, Status = ? WHERE CoachID = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, coach.getName());
            pstmt.setString(2, coach.getGender());
            pstmt.setString(3, coach.getPhoneNumber());
            pstmt.setString(4, coach.getEmail());
            pstmt.setString(5, coach.getQualification());
            pstmt.setString(6, coach.getStatus());
            pstmt.setInt(7, coach.getCoachId());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 删除教练
    public boolean deleteCoach(int coachId) {
        String sql = "DELETE FROM Coach WHERE CoachID = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, coachId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Searches for coaches based on a search term.
     * The search is performed on name, phone number, email, and specialty fields.
     * @param searchTerm The term to search for.
     * @return A list of matching Coach objects.
     */
    public List<Coach> searchCoaches(String searchTerm) {
        List<Coach> coaches = new ArrayList<>();
        String sql = "SELECT * FROM Coach WHERE Name LIKE ? OR PhoneNumber LIKE ? OR Email LIKE ? OR Qualification LIKE ? ORDER BY CoachID";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            String searchPattern = "%" + searchTerm + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            pstmt.setString(4, searchPattern);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Coach coach = mapRowToCoach(rs);
                coaches.add(coach);
            }
        } catch (SQLException e) {
            System.err.println("Database error searching coaches: " + e.getMessage());
        } finally {
            DBUtil.closeQuietly(rs);
            DBUtil.closeQuietly(pstmt);
            DBUtil.closeQuietly(conn);
        }
        return coaches;
    }

    /**
     * Maps a database row to a Coach object.
     * @param rs The ResultSet containing the coach data
     * @return A Coach object with the data from the ResultSet
     * @throws SQLException if a database access error occurs
     */
    private Coach mapRowToCoach(ResultSet rs) throws SQLException {
        Coach coach = new Coach();
        coach.setCoachId(rs.getInt("CoachID"));
        coach.setName(rs.getString("Name"));
        coach.setGender(rs.getString("Gender"));
        coach.setPhoneNumber(rs.getString("PhoneNumber"));
        coach.setEmail(rs.getString("Email"));
        coach.setQualification(rs.getString("Qualification"));
        coach.setStatus(rs.getString("Status"));
        return coach;
    }
} 