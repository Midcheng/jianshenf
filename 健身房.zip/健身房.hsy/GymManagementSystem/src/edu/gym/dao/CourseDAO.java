package edu.gym.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import edu.gym.helper.DBUtil;
import edu.gym.pojo.Course;

public class CourseDAO {
    
    // 添加课程
    public boolean addCourse(Course course) {
        String sql = "INSERT INTO Course (CourseName, CoachID, CourseTime, Location, Price, Capacity, CurrentEnrollment) VALUES (?, ?, ?, ?, ?, ?, 0)";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, course.getCourseName());
            pstmt.setInt(2, course.getCoachId());
            pstmt.setTimestamp(3, new java.sql.Timestamp(course.getCourseTime().getTime()));
            pstmt.setString(4, course.getLocation());
            pstmt.setBigDecimal(5, course.getPrice());
            pstmt.setInt(6, course.getCapacity());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // 获取所有课程
    public List<Course> getAllCourses() {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT c.*, co.Name as CoachName FROM Course c " +
                    "LEFT JOIN Coach co ON c.CoachID = co.CoachID";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                Course course = new Course();
                course.setCourseId(rs.getInt("CourseID"));
                course.setCourseName(rs.getString("CourseName"));
                course.setCoachId(rs.getInt("CoachID"));
                course.setCoachName(rs.getString("CoachName"));
                course.setCourseTime(rs.getTimestamp("CourseTime"));
                course.setLocation(rs.getString("Location"));
                course.setPrice(rs.getBigDecimal("Price"));
                course.setCapacity(rs.getInt("Capacity"));
                course.setCurrentEnrollment(rs.getInt("CurrentEnrollment"));
                courses.add(course);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return courses;
    }
    
    // 根据ID获取课程
    public Course getCourseById(int courseId) {
        String sql = "SELECT c.*, co.Name as CoachName FROM Course c " +
                    "LEFT JOIN Coach co ON c.CoachID = co.CoachID " +
                    "WHERE c.CourseID = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, courseId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                Course course = new Course();
                course.setCourseId(rs.getInt("CourseID"));
                course.setCourseName(rs.getString("CourseName"));
                course.setCoachId(rs.getInt("CoachID"));
                course.setCoachName(rs.getString("CoachName"));
                course.setCourseTime(rs.getTimestamp("CourseTime"));
                course.setLocation(rs.getString("Location"));
                course.setPrice(rs.getBigDecimal("Price"));
                course.setCapacity(rs.getInt("Capacity"));
                course.setCurrentEnrollment(rs.getInt("CurrentEnrollment"));
                return course;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    // 删除课程
    public boolean deleteCourse(int courseId) {
        String sql = "DELETE FROM Course WHERE CourseID = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, courseId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 搜索课程
    public List<Course> searchCourses(String searchTerm, String searchType) {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT c.*, ch.Name as CoachName " +
                    "FROM Course c " +
                    "LEFT JOIN Coach ch ON c.CoachID = ch.CoachID " +
                    "WHERE 1=1 ";

        // 根据搜索类型添加条件
        if (searchType != null) {
            switch (searchType) {
                case "courseName":
                    sql += "AND c.CourseName LIKE ? ";
                    break;
                case "coachName":
                    sql += "AND ch.Name LIKE ? ";
                    break;
                case "location":
                    sql += "AND c.Location LIKE ? ";
                    break;
                default:
                    sql += "AND (c.CourseName LIKE ? OR ch.Name LIKE ? OR c.Location LIKE ?) ";
                    break;
            }
        } else {
            sql += "AND (c.CourseName LIKE ? OR ch.Name LIKE ? OR c.Location LIKE ?) ";
        }

        sql += "ORDER BY c.CourseTime DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            // 设置搜索参数
            String searchPattern = "%" + searchTerm + "%";
            if (searchType != null && !searchType.equals("all")) {
                pstmt.setString(1, searchPattern);
            } else {
                pstmt.setString(1, searchPattern);
                pstmt.setString(2, searchPattern);
                pstmt.setString(3, searchPattern);
            }

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Course course = new Course();
                    course.setCourseId(rs.getInt("CourseID"));
                    course.setCourseName(rs.getString("CourseName"));
                    course.setDescription(rs.getString("Description"));
                    course.setCoachId(rs.getInt("CoachID"));
                    course.setCoachName(rs.getString("CoachName"));
                    course.setCourseTime(rs.getTimestamp("CourseTime"));
                    course.setLocation(rs.getString("Location"));
                    course.setPrice(rs.getBigDecimal("Price"));
                    course.setCapacity(rs.getInt("Capacity"));
                    course.setCurrentEnrollment(rs.getInt("CurrentEnrollment"));
                    courses.add(course);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }

    // 更新课程的报名人数
    public boolean updateEnrollment(int courseId, boolean increment) {
        String sql = "UPDATE Course SET CurrentEnrollment = CurrentEnrollment " + 
                    (increment ? "+ 1" : "- 1") +
                    " WHERE CourseID = ? AND " +
                    (increment ? "CurrentEnrollment < Capacity" : "CurrentEnrollment > 0");
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, courseId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 检查教练是否存在
     * @param coachId 教练ID
     * @return 如果教练存在返回true，否则返回false
     */
    public boolean isCoachExists(int coachId) {
        String sql = "SELECT COUNT(*) FROM Coach WHERE CoachID = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, coachId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 检查课程是否有预约记录
     * @param courseId 课程ID
     * @return 如果有预约记录返回true，否则返回false
     */
    public boolean hasBookings(int courseId) {
        String sql = "SELECT COUNT(*) FROM booking WHERE course_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, courseId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 更新课程信息
     * @param course 课程对象
     * @return 是否更新成功
     */
    public boolean updateCourse(Course course) {
        String sql = "UPDATE Course SET CourseName = ?, CoachID = ?, CourseTime = ?, " +
                    "Location = ?, Price = ?, Capacity = ? WHERE CourseID = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, course.getCourseName());
            stmt.setInt(2, course.getCoachId());
            stmt.setTimestamp(3, new java.sql.Timestamp(course.getCourseTime().getTime()));
            stmt.setString(4, course.getLocation());
            stmt.setBigDecimal(5, course.getPrice());
            stmt.setInt(6, course.getCapacity());
            stmt.setInt(7, course.getCourseId());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}