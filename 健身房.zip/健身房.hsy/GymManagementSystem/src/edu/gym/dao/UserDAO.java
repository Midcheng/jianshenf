package edu.gym.dao; // Changed package

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import edu.gym.helper.DBUtil; // Updated import
import edu.gym.pojo.User;   // Updated import

public class UserDAO {

    public User getUserByUsername(String username) {
        User user = null;
        String sql = "SELECT UserID, Username, Password, Role FROM User WHERE Username = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                user = new User();
                user.setUserId(rs.getInt("UserID"));
                user.setUsername(rs.getString("Username"));
                user.setPassword(rs.getString("Password"));
                user.setRole(rs.getString("Role"));
            }
        } catch (SQLException e) {
            System.err.println("Database error fetching user: " + e.getMessage());
        } finally {
            DBUtil.closeQuietly(rs);
            DBUtil.closeQuietly(pstmt);
            DBUtil.closeQuietly(conn);
        }
        return user;
    }
     // Add other methods as needed
}