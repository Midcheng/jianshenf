package edu.gym.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import edu.gym.helper.DBUtil;
import edu.gym.pojo.Appointment;

public class AppointmentDAO {
    
    // 获取会员的所有预约
    public List<Appointment> getMemberAppointments(int memberId) {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT a.*, c.CourseName, c.CourseTime, c.Location, ch.Name as CoachName " +
                    "FROM Appointment a " +
                    "JOIN Course c ON a.CourseID = c.CourseID " +
                    "LEFT JOIN Coach ch ON c.CoachID = ch.CoachID " +
                    "WHERE a.MemberID = ? AND a.Status = 'Active' " +
                    "ORDER BY c.CourseTime DESC";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, memberId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Appointment appointment = new Appointment();
                    appointment.setAppointmentId(rs.getInt("AppointmentID"));
                    appointment.setMemberId(rs.getInt("MemberID"));
                    appointment.setCourseId(rs.getInt("CourseID"));
                    appointment.setCourseName(rs.getString("CourseName"));
                    appointment.setCoachName(rs.getString("CoachName"));
                    appointment.setAppointmentDate(rs.getTimestamp("AppointmentDate"));
                    appointment.setStatus(rs.getString("Status"));
                    appointment.setCourseTime(rs.getTimestamp("CourseTime"));
                    appointment.setLocation(rs.getString("Location"));
                    appointments.add(appointment);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return appointments;
    }

    // 创建预约
    public boolean createAppointment(int memberId, int courseId) {
        String sql = "INSERT INTO Appointment (MemberID, CourseID, Status) VALUES (?, ?, 'Active')";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, memberId);
            pstmt.setInt(2, courseId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 取消预约
    public boolean cancelAppointment(int appointmentId, int memberId) {
        String sql = "UPDATE Appointment SET Status = 'Cancelled' " +
                    "WHERE AppointmentID = ? AND MemberID = ? AND Status = 'Active'";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, appointmentId);
            pstmt.setInt(2, memberId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 检查是否已经预约过该课程
    public boolean hasActiveAppointment(int memberId, int courseId) {
        String sql = "SELECT COUNT(*) FROM Appointment " +
                    "WHERE MemberID = ? AND CourseID = ? AND Status = 'Active'";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, memberId);
            pstmt.setInt(2, courseId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // 根据ID获取预约信息
    public Appointment getAppointmentById(int appointmentId) {
        String sql = "SELECT a.*, c.CourseName, c.CourseTime, c.Location, ch.Name as CoachName " +
                    "FROM Appointment a " +
                    "JOIN Course c ON a.CourseID = c.CourseID " +
                    "LEFT JOIN Coach ch ON c.CoachID = ch.CoachID " +
                    "WHERE a.AppointmentID = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, appointmentId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Appointment appointment = new Appointment();
                    appointment.setAppointmentId(rs.getInt("AppointmentID"));
                    appointment.setMemberId(rs.getInt("MemberID"));
                    appointment.setCourseId(rs.getInt("CourseID"));
                    appointment.setCourseName(rs.getString("CourseName"));
                    appointment.setCoachName(rs.getString("CoachName"));
                    appointment.setAppointmentDate(rs.getTimestamp("AppointmentDate"));
                    appointment.setStatus(rs.getString("Status"));
                    appointment.setCourseTime(rs.getTimestamp("CourseTime"));
                    appointment.setLocation(rs.getString("Location"));
                    return appointment;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // 获取所有预约
    public List<Appointment> getAllAppointments() {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT a.*, m.Name as MemberName, c.CourseName, co.Name as CoachName " +
                    "FROM Appointment a " +
                    "LEFT JOIN Member m ON a.MemberID = m.MemberID " +
                    "LEFT JOIN Course c ON a.CourseID = c.CourseID " +
                    "LEFT JOIN Coach co ON c.CoachID = co.CoachID " +
                    "ORDER BY a.AppointmentDate DESC";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                Appointment appointment = new Appointment();
                appointment.setAppointmentId(rs.getInt("AppointmentID"));
                appointment.setMemberId(rs.getInt("MemberID"));
                appointment.setMemberName(rs.getString("MemberName"));
                appointment.setCourseId(rs.getInt("CourseID"));
                appointment.setCourseName(rs.getString("CourseName"));
                appointment.setCoachName(rs.getString("CoachName"));
                appointment.setAppointmentDate(rs.getTimestamp("AppointmentDate"));
                appointment.setStatus(rs.getString("Status"));
                appointments.add(appointment);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return appointments;
    }
    
    // 添加预约
    public boolean addAppointment(Appointment appointment) {
        String sql = "INSERT INTO Appointment (MemberID, CourseID, AppointmentDate, Status) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, appointment.getMemberId());
            pstmt.setInt(2, appointment.getCourseId());
            pstmt.setTimestamp(3, new java.sql.Timestamp(appointment.getAppointmentDate().getTime()));
            pstmt.setString(4, appointment.getStatus());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // 更新预约状态
    public boolean updateAppointmentStatus(int appointmentId, String status) {
        String sql = "UPDATE Appointment SET Status = ? WHERE AppointmentID = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, status);
            pstmt.setInt(2, appointmentId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // 删除预约
    public boolean deleteAppointment(int appointmentId) {
        String sql = "DELETE FROM Appointment WHERE AppointmentID = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, appointmentId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 搜索预约
     * @param searchTerm 搜索关键词
     * @return 预约列表
     */
    public List<Appointment> searchAppointments(String searchTerm) {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT a.*, m.Name as memberName, c.CourseName, co.Name as coachName " +
                    "FROM Appointment a " +
                    "LEFT JOIN Member m ON a.MemberID = m.MemberID " +
                    "LEFT JOIN Course c ON a.CourseID = c.CourseID " +
                    "LEFT JOIN Coach co ON c.CoachID = co.CoachID " +
                    "WHERE m.Name LIKE ? OR c.CourseName LIKE ? OR co.Name LIKE ? " +
                    "ORDER BY a.AppointmentDate DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            String searchPattern = "%" + searchTerm + "%";
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            stmt.setString(3, searchPattern);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Appointment appointment = new Appointment();
                    appointment.setAppointmentId(rs.getInt("AppointmentID"));
                    appointment.setMemberId(rs.getInt("MemberID"));
                    appointment.setCourseId(rs.getInt("CourseID"));
                    appointment.setAppointmentDate(rs.getTimestamp("AppointmentDate"));
                    appointment.setStatus(rs.getString("Status"));
                    appointment.setMemberName(rs.getString("memberName"));
                    appointment.setCourseName(rs.getString("CourseName"));
                    appointment.setCoachName(rs.getString("coachName"));
                    appointments.add(appointment);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return appointments;
    }
}