package edu.gym.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date; // Use java.sql.Date for database interaction

import edu.gym.helper.DBUtil;
import edu.gym.pojo.Member;

public class MemberDAO {
	 public static Member getMemberByUserId(int userId) {
	        String sql = "SELECT * FROM Member WHERE UserID = ?";
	        Connection conn = null;
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	        Member member = null;

	        try {
	            conn = DBUtil.getConnection();
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, userId);
	            rs = pstmt.executeQuery();

	            if (rs.next()) {
	                member = new Member();
	                member.setMemberId(rs.getInt("MemberID"));
	                member.setName(rs.getString("Name"));
	                member.setGender(rs.getString("Gender"));
	                member.setBirthDate(rs.getDate("BirthDate"));
	                member.setPhoneNumber(rs.getString("PhoneNumber"));
	                member.setEmail(rs.getString("Email"));
	                member.setRegistrationDate(rs.getDate("RegistrationDate"));
	                member.setMembershipLevel(rs.getString("MembershipLevel"));
	                member.setStatus(rs.getString("Status"));
	                member.setEmergencyContact(rs.getString("EmergencyContact"));
	                member.setUsername(rs.getString("Username"));
	                member.setPassword(rs.getString("Password"));
	            }
	        } catch (SQLException e) {
	            System.err.println("Database error getting member by user ID: " + e.getMessage());
	        } finally {
	            DBUtil.closeQuietly(rs);
	            DBUtil.closeQuietly(pstmt);
	            DBUtil.closeQuietly(conn);
	        }
	        return member;
	    }

    public Member getMemberByUsername(String username) {
        String sql = "SELECT * FROM Member WHERE Username = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Member member = null;

        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                member = new Member();
                member.setMemberId(rs.getInt("MemberID"));
                member.setName(rs.getString("Name"));
                member.setGender(rs.getString("Gender"));
                member.setBirthDate(rs.getDate("BirthDate"));
                member.setPhoneNumber(rs.getString("PhoneNumber"));
                member.setEmail(rs.getString("Email"));
                member.setRegistrationDate(rs.getDate("RegistrationDate"));
                member.setMembershipLevel(rs.getString("MembershipLevel"));
                member.setStatus(rs.getString("Status"));
                member.setEmergencyContact(rs.getString("EmergencyContact"));
                member.setUsername(rs.getString("Username"));
                member.setPassword(rs.getString("Password"));
            }
        } catch (SQLException e) {
            System.err.println("Database error getting member by username: " + e.getMessage());
        } finally {
            DBUtil.closeQuietly(rs);
            DBUtil.closeQuietly(pstmt);
            DBUtil.closeQuietly(conn);
        }
        return member;
    }

    /**
     * Retrieves all members from the database.
     * @return A list of Member objects.
     */
    public List<Member> getAllMembers() {
        List<Member> members = new ArrayList<>();
        String sql = "SELECT * FROM Member ORDER BY MemberID"; // Or order by Name, etc.
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Member member = mapRowToMember(rs);
                members.add(member);
            }
        } catch (SQLException e) {
            System.err.println("Database error getting all members: " + e.getMessage());
            // Handle appropriately
        } finally {
            DBUtil.closeQuietly(rs);
            DBUtil.closeQuietly(stmt);
            DBUtil.closeQuietly(conn);
        }
        return members;
    }

    /**
     * Adds a new member to the database.
     * @param member The Member object containing the data for the new member.
     * @return true if the member was added successfully, false otherwise.
     */
    public boolean addMember(Member member) {
        String sql = "INSERT INTO Member (Name, Gender, BirthDate, PhoneNumber, Email, RegistrationDate, MembershipLevel, Status, EmergencyContact, Username, Password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean success = false;

        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, member.getName());
            pstmt.setString(2, member.getGender());
            // Convert java.util.Date to java.sql.Date for JDBC
            pstmt.setDate(3, (member.getBirthDate() != null) ? new Date(member.getBirthDate().getTime()) : null);
            pstmt.setString(4, member.getPhoneNumber());
            pstmt.setString(5, member.getEmail());
            pstmt.setDate(6, (member.getRegistrationDate() != null) ? new Date(member.getRegistrationDate().getTime()) : null);
            pstmt.setString(7, member.getMembershipLevel());
            pstmt.setString(8, member.getStatus()); // Ensure status is set before calling addMember
            pstmt.setString(9, member.getEmergencyContact());
            pstmt.setString(10, member.getUsername());
            pstmt.setString(11, member.getPassword());

            int rowsAffected = pstmt.executeUpdate();
            success = (rowsAffected > 0);

        } catch (SQLException e) {
            System.err.println("Database error adding member: " + e.getMessage());
            // Handle appropriately (e.g., check for duplicate email/phone if they are unique)
        } finally {
            DBUtil.closeQuietly(pstmt);
            DBUtil.closeQuietly(conn);
        }
        return success;
    }

     /**
     * Deletes a member from the database by their ID.
     * @param memberId The ID of the member to delete.
     * @return true if the member was deleted successfully, false otherwise.
     * @throws SQLException if a database access error occurs or if the member has related records
     */
    public boolean deleteMember(int memberId) throws SQLException {
        String sql = "DELETE FROM Member WHERE MemberID = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean success = false;

        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, memberId);

            int rowsAffected = pstmt.executeUpdate();
            success = (rowsAffected > 0);

        } finally {
            DBUtil.closeQuietly(pstmt);
            DBUtil.closeQuietly(conn);
        }
        return success;
    }

    /**
     * Helper method to map a ResultSet row to a Member object.
     * @param rs The ResultSet pointing to the current row.
     * @return A Member object populated with data from the row.
     * @throws SQLException If a database access error occurs.
     */
    private Member mapRowToMember(ResultSet rs) throws SQLException {
        Member member = new Member();
        member.setMemberId(rs.getInt("MemberID"));
        member.setName(rs.getString("Name"));
        member.setGender(rs.getString("Gender"));
        member.setBirthDate(rs.getDate("BirthDate")); // Gets java.sql.Date, assignable to java.util.Date
        member.setPhoneNumber(rs.getString("PhoneNumber"));
        member.setEmail(rs.getString("Email"));
        member.setRegistrationDate(rs.getDate("RegistrationDate"));
        member.setMembershipLevel(rs.getString("MembershipLevel"));
        member.setStatus(rs.getString("Status"));
        member.setEmergencyContact(rs.getString("EmergencyContact"));
        member.setUsername(rs.getString("Username"));
        member.setPassword(rs.getString("Password"));
        // Map other fields if they exist
        return member;
    }

    /**
     * Retrieves a member from the database by their ID.
     * @param memberId The ID of the member to retrieve.
     * @return The Member object if found, null otherwise.
     */
    public Member getMemberById(int memberId) {
        String sql = "SELECT * FROM Member WHERE MemberID = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Member member = null;

        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, memberId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                member = mapRowToMember(rs);
            }
        } catch (SQLException e) {
            System.err.println("Database error getting member by ID: " + e.getMessage());
        } finally {
            DBUtil.closeQuietly(rs);
            DBUtil.closeQuietly(pstmt);
            DBUtil.closeQuietly(conn);
        }
        return member;
    }

    /**
     * Updates an existing member's information in the database.
     * @param member The Member object containing the updated data.
     * @return true if the member was updated successfully, false otherwise.
     */
    public boolean updateMember(Member member) {
        String sql = "UPDATE Member SET Name=?, Gender=?, BirthDate=?, PhoneNumber=?, Email=?, " +
                    "MembershipLevel=?, Status=?, EmergencyContact=?, Username=?, Password=? " +
                    "WHERE MemberID=?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean success = false;

        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, member.getName());
            pstmt.setString(2, member.getGender());
            pstmt.setDate(3, (member.getBirthDate() != null) ? new Date(member.getBirthDate().getTime()) : null);
            pstmt.setString(4, member.getPhoneNumber());
            pstmt.setString(5, member.getEmail());
            pstmt.setString(6, member.getMembershipLevel());
            pstmt.setString(7, member.getStatus());
            pstmt.setString(8, member.getEmergencyContact());
            pstmt.setString(9, member.getUsername());
            pstmt.setString(10, member.getPassword());
            pstmt.setInt(11, member.getMemberId());

            int rowsAffected = pstmt.executeUpdate();
            success = (rowsAffected > 0);

        } catch (SQLException e) {
            System.err.println("Database error updating member: " + e.getMessage());
        } finally {
            DBUtil.closeQuietly(pstmt);
            DBUtil.closeQuietly(conn);
        }
        return success;
    }

    /**
     * Searches for members based on a search term.
     * The search is performed on name, phone number, email, and username fields.
     * @param searchTerm The term to search for.
     * @return A list of matching Member objects.
     */
    public List<Member> searchMembers(String searchTerm) {
        List<Member> members = new ArrayList<>();
        String sql = "SELECT * FROM Member WHERE Name LIKE ? OR PhoneNumber LIKE ? OR Email LIKE ? OR Username LIKE ? ORDER BY MemberID";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            String searchPattern = "%" + searchTerm + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            pstmt.setString(4, searchPattern);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Member member = mapRowToMember(rs);
                members.add(member);
            }
        } catch (SQLException e) {
            System.err.println("Database error searching members: " + e.getMessage());
        } finally {
            DBUtil.closeQuietly(rs);
            DBUtil.closeQuietly(pstmt);
            DBUtil.closeQuietly(conn);
        }
        return members;
    }

    // Optional: Add getInactiveMembers() or filter in getAllMembers() based on status
}