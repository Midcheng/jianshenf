package edu.gym.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSON;

import edu.gym.dao.MemberDAO;
import edu.gym.pojo.Member;

@WebServlet("/ViewMembersServlet")
public class ViewMembersServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private MemberDAO memberDAO;

    @Override
    public void init() throws ServletException {
        memberDAO = new MemberDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        // --- Authorization Check ---
        HttpSession session = request.getSession(false); // Don't create session if it doesn't exist
        if (session == null || !"admin".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN); // 403 Forbidden
            out.print("{\"error\": \"Unauthorized access\"}");
            out.flush();
            return;
        }
        // --- End Authorization Check ---

        try {
            List<Member> members = memberDAO.getAllMembers();
            // Convert list to JSON string using fastjson
            // Use property naming strategy if needed for date formatting, or format dates in JS
            String jsonOutput = JSON.toJSONStringWithDateFormat(members, "yyyy-MM-dd"); // Format dates
            out.print(jsonOutput);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // 500 Internal Server Error
            out.print("{\"error\": \"Error fetching members: " + e.getMessage() + "\"}");
            System.err.println("Error in ViewMembersServlet: " + e.getMessage());
            e.printStackTrace();
        } finally {
            out.flush();
        }
    }

     @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // Typically, viewing data is done via GET. Handle POST if necessary.
         doGet(req, resp);
    }
}