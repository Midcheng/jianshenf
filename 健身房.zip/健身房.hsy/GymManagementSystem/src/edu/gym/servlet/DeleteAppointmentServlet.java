package edu.gym.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSONObject;

import edu.gym.dao.AppointmentDAO;
import edu.gym.dao.CourseDAO;

@WebServlet("/DeleteAppointmentServlet")
public class DeleteAppointmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private AppointmentDAO appointmentDAO;
    private CourseDAO courseDAO;

    @Override
    public void init() throws ServletException {
        appointmentDAO = new AppointmentDAO();
        courseDAO = new CourseDAO();
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JSONObject jsonResponse = new JSONObject();

        // 权限检查
        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "未授权访问");
            out.print(jsonResponse.toJSONString());
            out.flush();
            return;
        }

        String appointmentIdStr = request.getParameter("appointmentId");
        if (appointmentIdStr == null || appointmentIdStr.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "预约ID不能为空");
            out.print(jsonResponse.toJSONString());
            out.flush();
            return;
        }

        try {
            int appointmentId = Integer.parseInt(appointmentIdStr);
            
            // 获取预约信息
            if (appointmentDAO.getAppointmentById(appointmentId) == null) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "预约不存在");
                out.print(jsonResponse.toJSONString());
                out.flush();
                return;
            }

            // 删除预约
            boolean success = appointmentDAO.deleteAppointment(appointmentId);
            if (success) {
                jsonResponse.put("success", true);
                jsonResponse.put("message", "预约删除成功");
            } else {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "预约删除失败");
            }
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "无效的预约ID格式");
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "删除预约时发生错误: " + e.getMessage());
        }

        out.print(jsonResponse.toJSONString());
        out.flush();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.print("{\"error\": \"GET method not allowed for deleting appointments.\"}");
        out.flush();
    }
} 