package edu.gym.servlet;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import edu.gym.dao.CoachDAO;
import edu.gym.pojo.Coach;

@WebServlet("/GetCoachesServlet")
public class GetCoachesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CoachDAO coachDAO = new CoachDAO();
    private Gson gson = new Gson();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try {
            List<Coach> coaches = coachDAO.getAllCoaches();
            String jsonResponse = gson.toJson(coaches);
            response.getWriter().write(jsonResponse);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\": \"" + e.getMessage() + "\"}");
        }
    }
} 