package edu.gym.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSONObject;

import edu.gym.dao.MemberDAO;
import edu.gym.pojo.Member;

@WebServlet("/EditMemberServlet")
public class EditMemberServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private MemberDAO memberDAO;

    @Override
    public void init() throws ServletException {
        memberDAO = new MemberDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        PrintWriter out = response.getWriter();
        JSONObject jsonResponse = new JSONObject();

        // 权限检查
        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "未授权访问");
            out.print(jsonResponse.toJSONString());
            out.flush();
            return;
        }

        try {
            // 获取表单数据
            String memberIdStr = request.getParameter("memberId");
            if (memberIdStr == null || memberIdStr.trim().isEmpty() || "undefined".equals(memberIdStr)) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "无效的会员ID");
                out.print(jsonResponse.toJSONString());
                out.flush();
                return;
            }

            int memberId;
            try {
                memberId = Integer.parseInt(memberIdStr);
            } catch (NumberFormatException e) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "无效的会员ID格式");
                out.print(jsonResponse.toJSONString());
                out.flush();
                return;
            }

            String name = request.getParameter("name");
            String gender = request.getParameter("gender");
            String phoneNumber = request.getParameter("phoneNumber");
            String email = request.getParameter("email");
            String membershipLevel = request.getParameter("membershipLevel");
            String status = request.getParameter("status");
            String emergencyContact = request.getParameter("emergencyContact");
            String username = request.getParameter("username");
            String password = request.getParameter("password");

            // 获取现有会员信息
            Member member = memberDAO.getMemberById(memberId);
            if (member == null) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "会员不存在");
                out.print(jsonResponse.toJSONString());
                out.flush();
                return;
            }

            // 更新会员信息
            member.setName(name);
            member.setGender(gender);
            member.setPhoneNumber(phoneNumber);
            member.setEmail(email);
            member.setMembershipLevel(membershipLevel);
            member.setStatus(status);
            member.setEmergencyContact(emergencyContact);
            member.setUsername(username);
            if (password != null && !password.trim().isEmpty()) {
                member.setPassword(password);
            }

            // 保存更新
            boolean success = memberDAO.updateMember(member);
            if (success) {
                jsonResponse.put("success", true);
                jsonResponse.put("message", "会员信息更新成功");
            } else {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "会员信息更新失败");
            }
        } catch (Exception e) {
            jsonResponse.put("success", false);
            jsonResponse.put("message", "更新会员信息时发生错误: " + e.getMessage());
            e.printStackTrace();
        }

        out.print(jsonResponse.toJSONString());
        out.flush();
    }
} 