package edu.gym.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.alibaba.fastjson.JSON;
import edu.gym.dao.CoachDAO;
import edu.gym.pojo.Coach;

@WebServlet("/AddCoachServlet")
public class AddCoachServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CoachDAO coachDAO;

    @Override
    public void init() throws ServletException {
        coachDAO = new CoachDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // 权限检查
        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.getWriter().write("{\"success\": false, \"message\": \"未授权访问\"}");
            return;
        }

        try {
            // 从请求参数中获取教练信息
            Coach coach = new Coach();
            coach.setName(request.getParameter("name"));
            coach.setGender(request.getParameter("gender"));
            coach.setPhoneNumber(request.getParameter("phoneNumber"));
            coach.setEmail(request.getParameter("email"));
            coach.setQualification(request.getParameter("qualification"));
            coach.setStatus(request.getParameter("status"));

            // 添加教练
            boolean success = coachDAO.addCoach(coach);

            if (success) {
                response.getWriter().write("{\"success\": true, \"message\": \"教练添加成功\"}");
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"success\": false, \"message\": \"教练添加失败\"}");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"" + e.getMessage().replace("\"", "\\\"") + "\"}");
        }
    }
} 