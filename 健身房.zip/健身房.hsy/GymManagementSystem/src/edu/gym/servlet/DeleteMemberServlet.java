package edu.gym.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSONObject;

import edu.gym.dao.MemberDAO;
import edu.gym.pojo.Member;

@WebServlet("/DeleteMemberServlet")
public class DeleteMemberServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private MemberDAO memberDAO;

    @Override
    public void init() throws ServletException {
        memberDAO = new MemberDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JSONObject jsonResponse = new JSONObject();

        // 权限检查
        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "未授权访问");
            out.print(jsonResponse.toJSONString());
            out.flush();
            return;
        }

        String memberIdStr = request.getParameter("memberId");
        int memberId = -1;

        try {
            memberId = Integer.parseInt(memberIdStr);
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "无效的会员ID格式");
            out.print(jsonResponse.toJSONString());
            out.flush();
            return;
        }

        try {
            // 检查会员是否存在
            Member member = memberDAO.getMemberById(memberId);
            if (member == null) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "会员不存在");
                out.print(jsonResponse.toJSONString());
                out.flush();
                return;
            }

            // 尝试删除会员
            boolean success = memberDAO.deleteMember(memberId);
            if (success) {
                jsonResponse.put("success", true);
                jsonResponse.put("message", "会员删除成功");
            } else {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "无法删除会员，该会员可能有关联的预约记录");
            }
        } catch (SQLException e) {
            if (e.getMessage().contains("foreign key constraint")) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "无法删除会员，该会员有关联的预约记录，请先删除相关预约");
            } else {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "删除会员时发生错误: " + e.getMessage());
            }
        } catch (Exception e) {
            jsonResponse.put("success", false);
            jsonResponse.put("message", "删除会员时发生错误: " + e.getMessage());
        }

        out.print(jsonResponse.toJSONString());
        out.flush();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // Deleting data should typically be done via POST or DELETE methods.
        // Avoid deletion via GET. Return an error or redirect.
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED); // 405 Method Not Allowed
        PrintWriter out = resp.getWriter();
        out.print("{\"error\": \"GET method not allowed for deleting members.\"}");
        out.flush();
    }
}