package edu.gym.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.alibaba.fastjson.JSON;
import edu.gym.dao.CourseDAO;
import edu.gym.pojo.Course;

@WebServlet("/AddCourseServlet")
public class AddCourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CourseDAO courseDAO;

    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException("Failed to initialize CourseDAO", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // 权限检查
        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.getWriter().write("{\"success\": false, \"message\": \"未授权访问\"}");
            return;
        }

        try {
            // 从请求参数中获取课程信息
            String courseName = request.getParameter("courseName");
            String description = request.getParameter("description");
            String coachIdStr = request.getParameter("coachId");
            String priceStr = request.getParameter("price");
            String capacityStr = request.getParameter("capacity");
            String location = request.getParameter("location");
            String courseTimeStr = request.getParameter("courseTime");

            // 验证必填字段
            if (courseName == null || courseName.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"课程名称不能为空\"}");
                return;
            }

            if (coachIdStr == null || coachIdStr.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"教练ID不能为空\"}");
                return;
            }

            if (priceStr == null || priceStr.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"课程价格不能为空\"}");
                return;
            }

            if (capacityStr == null || capacityStr.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"课程容量不能为空\"}");
                return;
            }

            if (location == null || location.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"课程地点不能为空\"}");
                return;
            }

            if (courseTimeStr == null || courseTimeStr.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"课程时间不能为空\"}");
                return;
            }

            // 创建课程对象
            Course course = new Course();
            course.setCourseName(courseName);
            course.setDescription(description != null ? description : "");
            
            try {
                int coachId = Integer.parseInt(coachIdStr);
                // 验证教练是否存在
                if (!courseDAO.isCoachExists(coachId)) {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    response.getWriter().write("{\"success\": false, \"message\": \"指定的教练不存在\"}");
                    return;
                }
                course.setCoachId(coachId);
            } catch (NumberFormatException e) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"无效的教练ID格式\"}");
                return;
            }

            try {
                BigDecimal price = new BigDecimal(priceStr);
                if (price.compareTo(BigDecimal.ZERO) <= 0) {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    response.getWriter().write("{\"success\": false, \"message\": \"课程价格必须大于0\"}");
                    return;
                }
                course.setPrice(price);
            } catch (NumberFormatException e) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"无效的价格格式\"}");
                return;
            }

            try {
                int capacity = Integer.parseInt(capacityStr);
                if (capacity <= 0) {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    response.getWriter().write("{\"success\": false, \"message\": \"课程容量必须大于0\"}");
                    return;
                }
                course.setCapacity(capacity);
            } catch (NumberFormatException e) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"无效的容量格式\"}");
                return;
            }

            try {
                Date courseTime = new Date(courseTimeStr);
                course.setCourseTime(courseTime);
            } catch (Exception e) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"无效的时间格式\"}");
                return;
            }

            course.setLocation(location);
            course.setCurrentEnrollment(0);

            // 添加课程
            boolean success = courseDAO.addCourse(course);

            if (success) {
                response.getWriter().write("{\"success\": true, \"message\": \"课程添加成功\"}");
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"success\": false, \"message\": \"课程添加失败\"}");
            }
        } catch (Exception e) {
            e.printStackTrace(); // 添加服务器端日志
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"服务器错误: " + e.getMessage().replace("\"", "\\\"") + "\"}");
        }
    }
} 