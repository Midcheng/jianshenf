package edu.gym.servlet;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.alibaba.fastjson.JSON;
import edu.gym.dao.CourseDAO;
import edu.gym.pojo.Course;

@WebServlet("/SearchCoursesServlet")
public class SearchCoursesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CourseDAO courseDAO;

    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException("Failed to initialize CourseDAO", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // 权限检查
        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.getWriter().write("{\"success\": false, \"message\": \"未授权访问\"}");
            return;
        }

        try {
            String searchTerm = request.getParameter("searchTerm");
            String searchType = request.getParameter("searchType");

            // 如果搜索词为空，返回所有课程
            if (searchTerm == null || searchTerm.trim().isEmpty()) {
                List<Course> courses = courseDAO.getAllCourses();
                response.getWriter().write(JSON.toJSONString(courses));
                return;
            }

            // 搜索课程
            List<Course> courses = courseDAO.searchCourses(searchTerm, searchType);
            response.getWriter().write(JSON.toJSONString(courses));
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"搜索课程失败: " + e.getMessage().replace("\"", "\\\"") + "\"}");
        }
    }
} 