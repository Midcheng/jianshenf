package edu.gym.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.alibaba.fastjson.JSON;
import edu.gym.dao.CoachDAO;
import edu.gym.pojo.Coach;

@WebServlet("/UpdateCoachServlet")
public class UpdateCoachServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CoachDAO coachDAO;

    @Override
    public void init() throws ServletException {
        try {
            coachDAO = new CoachDAO();
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException("Failed to initialize CoachDAO", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // 权限检查
        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.getWriter().write("{\"success\": false, \"message\": \"未授权访问\"}");
            return;
        }

        try {
            // 从请求参数中获取教练信息
            String coachIdStr = request.getParameter("coachId");
            if (coachIdStr == null || coachIdStr.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"教练ID不能为空\"}");
                return;
            }

            // 检查教练是否存在
            int coachId;
            try {
                coachId = Integer.parseInt(coachIdStr);
            } catch (NumberFormatException e) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"无效的教练ID格式\"}");
                return;
            }

            Coach existingCoach = coachDAO.getCoachById(coachId);
            if (existingCoach == null) {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("{\"success\": false, \"message\": \"教练不存在\"}");
                return;
            }

            String name = request.getParameter("name");
            String gender = request.getParameter("gender");
            String phoneNumber = request.getParameter("phoneNumber");
            String email = request.getParameter("email");
            String qualification = request.getParameter("qualification");
            String status = request.getParameter("status");

            if (name == null || name.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"教练姓名不能为空\"}");
                return;
            }

            // 更新教练信息
            existingCoach.setName(name);
            existingCoach.setGender(gender != null ? gender : existingCoach.getGender());
            existingCoach.setPhoneNumber(phoneNumber != null ? phoneNumber : existingCoach.getPhoneNumber());
            existingCoach.setEmail(email != null ? email : existingCoach.getEmail());
            existingCoach.setQualification(qualification != null ? qualification : existingCoach.getQualification());
            existingCoach.setStatus(status != null ? status : existingCoach.getStatus());

            // 执行更新
            boolean success = coachDAO.updateCoach(existingCoach);

            if (success) {
                response.getWriter().write("{\"success\": true, \"message\": \"教练信息更新成功\"}");
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"success\": false, \"message\": \"教练信息更新失败\"}");
            }
        } catch (Exception e) {
            e.printStackTrace(); // 添加服务器端日志
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"服务器错误: " + e.getMessage().replace("\"", "\\\"") + "\"}");
        }
    }
} 