package edu.gym.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;

import edu.gym.dao.MemberDAO;
import edu.gym.pojo.Member;
import edu.gym.pojo.User;

@WebServlet("/GetMemberProfileServlet")
public class GetMemberProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private MemberDAO memberDAO;

    @Override
    public void init() throws ServletException {
        memberDAO = new MemberDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        // 检查用户是否登录
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"error\": \"未登录或会话已过期\"}");
            return;
        }

        try {
            Object userObj = session.getAttribute("user");
            Member member = null;

            if (userObj instanceof User) {
                // 如果是管理员登录，通过UserID获取会员信息
                User user = (User) userObj;
                member = MemberDAO.getMemberByUserId(user.getUserId());
            } else if (userObj instanceof Member) {
                // 如果是会员直接登录，直接使用会员信息
                member = (Member) userObj;
            }

            if (member != null) {
                // 使用FastJSON转换为JSON字符串，格式化日期
                String jsonOutput = JSON.toJSONStringWithDateFormat(member, 
                    "yyyy-MM-dd",
                    SerializerFeature.WriteMapNullValue,
                    SerializerFeature.WriteDateUseDateFormat);
                
                out.print(jsonOutput);
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print("{\"error\": \"未找到会员信息\"}");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"" + e.getMessage() + "\"}");
            e.printStackTrace();
        }
    }
}