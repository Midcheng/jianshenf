package edu.gym.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import edu.gym.dao.CourseDAO;
import edu.gym.pojo.Course;

@WebServlet("/UpdateCourseServlet")
public class UpdateCourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CourseDAO courseDAO;

    @Override
    public void init() throws ServletException {
        try {
            courseDAO = new CourseDAO();
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException("Failed to initialize CourseDAO", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // 权限检查
        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.getWriter().write("{\"success\": false, \"message\": \"未授权访问\"}");
            return;
        }

        try {
            // 读取请求体中的JSON数据
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = request.getReader().readLine()) != null) {
                sb.append(line);
            }
            JSONObject jsonData = JSON.parseObject(sb.toString());

            // 获取课程ID
            String courseIdStr = jsonData.getString("courseId");
            if (courseIdStr == null || courseIdStr.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"课程ID不能为空\"}");
                return;
            }

            int courseId = Integer.parseInt(courseIdStr);

            // 检查课程是否存在
            Course existingCourse = courseDAO.getCourseById(courseId);
            if (existingCourse == null) {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("{\"success\": false, \"message\": \"课程不存在\"}");
                return;
            }

            // 获取并验证必填字段
            String courseName = jsonData.getString("courseName");
            if (courseName == null || courseName.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"课程名称不能为空\"}");
                return;
            }

            String coachIdStr = jsonData.getString("coachId");
            if (coachIdStr == null || coachIdStr.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"教练ID不能为空\"}");
                return;
            }

            int coachId = Integer.parseInt(coachIdStr);

            // 检查教练是否存在
            if (!courseDAO.isCoachExists(coachId)) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"教练不存在\"}");
                return;
            }

            // 获取并验证其他字段
            String courseTimeStr = jsonData.getString("courseTime");
            if (courseTimeStr == null || courseTimeStr.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"课程时间不能为空\"}");
                return;
            }

            String location = jsonData.getString("location");
            if (location == null || location.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"课程地点不能为空\"}");
                return;
            }

            String priceStr = jsonData.getString("price");
            if (priceStr == null || priceStr.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"课程价格不能为空\"}");
                return;
            }

            String capacityStr = jsonData.getString("capacity");
            if (capacityStr == null || capacityStr.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"课程容量不能为空\"}");
                return;
            }

            // 更新课程信息
            existingCourse.setCourseName(courseName);
            existingCourse.setCoachId(coachId);
            
            // 处理课程时间
            try {
                // 将前端传来的时间字符串转换为正确的格式
                String formattedTime = courseTimeStr.replace("T", " ");
                if (!formattedTime.contains(":")) {
                    formattedTime += " 00:00:00";
                } else if (formattedTime.split(":").length == 2) {
                    formattedTime += ":00";
                }
                existingCourse.setCourseTime(Timestamp.valueOf(formattedTime));
            } catch (IllegalArgumentException e) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"无效的时间格式，请使用 yyyy-MM-dd HH:mm:ss 格式\"}");
                return;
            }
            
            existingCourse.setLocation(location);
            existingCourse.setPrice(new BigDecimal(priceStr));
            existingCourse.setCapacity(Integer.parseInt(capacityStr));

            // 保存更新
            boolean success = courseDAO.updateCourse(existingCourse);
            if (success) {
                response.getWriter().write("{\"success\": true, \"message\": \"课程更新成功\"}");
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"success\": false, \"message\": \"课程更新失败\"}");
            }
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"success\": false, \"message\": \"无效的数字格式\"}");
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"更新课程失败: " + e.getMessage().replace("\"", "\\\"") + "\"}");
        }
    }
} 