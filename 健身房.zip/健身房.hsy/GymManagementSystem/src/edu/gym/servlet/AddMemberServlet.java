package edu.gym.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date; // ʹ�� java.util.Date

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSONObject;

import edu.gym.dao.MemberDAO;
import edu.gym.pojo.Member;

@WebServlet("/AddMemberServlet")
public class AddMemberServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private MemberDAO memberDAO;

    @Override
    public void init() throws ServletException {
        memberDAO = new MemberDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 设置请求和响应的字符编码
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        PrintWriter out = response.getWriter();
        JSONObject jsonResponse = new JSONObject();

        // --- Ȩ�޼�� ---
        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "未授权访问");
            out.print(jsonResponse.toJSONString());
            out.flush();
            return;
        }
        // --- Ȩ�޼����� ---

        try {
            // �������л�ȡ��������
            String name = request.getParameter("name");
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String gender = request.getParameter("gender");
            String birthDateStr = request.getParameter("birthDate");
            String phoneNumber = request.getParameter("phoneNumber");
            String email = request.getParameter("email");
            String registrationDateStr = request.getParameter("registrationDate");
            String membershipLevel = request.getParameter("membershipLevel");
            String status = request.getParameter("status");
            String emergencyContact = request.getParameter("emergencyContact");

            // --- �������֤ ---
            if (name == null || name.trim().isEmpty()) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "会员姓名不能为空");
                out.print(jsonResponse.toJSONString());
                out.flush();
                return;
            }
            if (username == null || username.trim().isEmpty()) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "账号不能为空");
                out.print(jsonResponse.toJSONString());
                out.flush();
                return;
            }
            if (password == null || password.trim().isEmpty()) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "密码不能为空");
                out.print(jsonResponse.toJSONString());
                out.flush();
                return;
            }
            if (password.length() < 6) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "密码长度不能少于6位");
                out.print(jsonResponse.toJSONString());
                out.flush();
                return;
            }
            if (status == null || status.trim().isEmpty()) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "会员状态不能为空");
                out.print(jsonResponse.toJSONString());
                out.flush();
                return;
            }
            // --- ֤ ---


            // ---  Member  ---
            Member newMember = new Member();
            newMember.setName(name.trim());
            newMember.setUsername(username.trim());
            newMember.setPassword(password.trim());
            newMember.setGender(gender); // Ϊַȡ <select>
            newMember.setPhoneNumber(phoneNumber);
            newMember.setEmail(email);
            newMember.setMembershipLevel(membershipLevel);
            newMember.setStatus(status.trim());
            newMember.setEmergencyContact(emergencyContact);

            //  ( yyyy-MM-dd ַ)
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
             dateFormat.setLenient(false); // ��������Ч���ڣ����� 2023-02-30

             try {
                if (birthDateStr != null && !birthDateStr.trim().isEmpty()) {
                    newMember.setBirthDate(dateFormat.parse(birthDateStr.trim()));
                }
                 if (registrationDateStr != null && !registrationDateStr.trim().isEmpty()) {
                    newMember.setRegistrationDate(dateFormat.parse(registrationDateStr.trim()));
                 } else {
                     // ���ע������δ�ṩ����������һ��Ĭ��ֵ�����統ǰ����
                     newMember.setRegistrationDate(new Date()); // ʹ�õ�ǰ����
                 }
            } catch (ParseException e) {
                 jsonResponse.put("success", false);
                 jsonResponse.put("message", "日期格式无效，请使用 YYYY-MM-DD 格式");
                 out.print(jsonResponse.toJSONString());
                 out.flush();
                 return;
            }
            // --- Member 󴴽 ---


            // ---  DAO ӻԱ ---
            boolean success = memberDAO.addMember(newMember);

            if (success) {
                jsonResponse.put("success", true);
                jsonResponse.put("message", "新会员添加成功");
            } else {
                 response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // ָʾ
                jsonResponse.put("success", false);
                jsonResponse.put("message", "添加会员失败，可能是数据库或系统错误");
            }

        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "添加会员时发生错误，内部错误: " + e.getMessage());
            System.err.println("Error in AddMemberServlet: " + e.getMessage());
            e.printStackTrace(); // ӡϸ󵽷־
        } finally {
            out.print(jsonResponse.toJSONString());
            out.flush();
        }
    }

     @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
         // GET ͨݣض򵽱ҳ
         resp.sendRedirect("add_member.html");
    }
}