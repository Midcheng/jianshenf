package edu.gym.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSONObject;

import edu.gym.dao.AppointmentDAO;
import edu.gym.dao.CourseDAO;
import edu.gym.pojo.Course;
import edu.gym.pojo.User;
import edu.gym.pojo.Member;
import edu.gym.dao.MemberDAO;

@WebServlet("/BookCourseServlet")
public class BookCourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private AppointmentDAO appointmentDAO;
    private CourseDAO courseDAO;

    @Override
    public void init() throws ServletException {
        appointmentDAO = new AppointmentDAO();
        courseDAO = new CourseDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JSONObject jsonResponse = new JSONObject();

        // 检查用户是否登录
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "未登录或会话已过期");
            out.print(jsonResponse.toJSONString());
            return;
        }

        try {
            // 获取课程ID
            String courseIdStr = request.getParameter("courseId");
            if (courseIdStr == null || courseIdStr.trim().isEmpty()) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "课程ID不能为空");
                out.print(jsonResponse.toJSONString());
                return;
            }

            int courseId = Integer.parseInt(courseIdStr);
            Course course = courseDAO.getCourseById(courseId);
            if (course == null) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "课程不存在");
                out.print(jsonResponse.toJSONString());
                return;
            }

            // 检查课程是否已满
            if (course.getCurrentEnrollment() >= course.getCapacity()) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "课程已满");
                out.print(jsonResponse.toJSONString());
                return;
            }

            // 获取会员ID
            Object userObj = session.getAttribute("user");
            int memberId;

            if (userObj instanceof User) {
                // 如果是管理员登录，通过UserID获取会员信息
                User user = (User) userObj;
                Member member = MemberDAO.getMemberByUserId(user.getUserId());
                if (member == null) {
                    jsonResponse.put("success", false);
                    jsonResponse.put("message", "未找到会员信息");
                    out.print(jsonResponse.toJSONString());
                    return;
                }
                memberId = member.getMemberId();
            } else if (userObj instanceof Member) {
                // 如果是会员直接登录，直接使用会员信息
                Member member = (Member) userObj;
                memberId = member.getMemberId();
            } else {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "无效的用户类型");
                out.print(jsonResponse.toJSONString());
                return;
            }

            // 检查是否已经预约过该课程
            if (appointmentDAO.hasActiveAppointment(memberId, courseId)) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "您已经预约过该课程");
                out.print(jsonResponse.toJSONString());
                return;
            }

            // 创建预约
            boolean success = appointmentDAO.createAppointment(memberId, courseId);
            if (success) {
                // 更新课程当前报名人数
                courseDAO.updateEnrollment(courseId, true);
                jsonResponse.put("success", true);
                jsonResponse.put("message", "课程预约成功");
            } else {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "课程预约失败");
            }

        } catch (NumberFormatException e) {
            jsonResponse.put("success", false);
            jsonResponse.put("message", "无效的课程ID格式");
        } catch (Exception e) {
            jsonResponse.put("success", false);
            jsonResponse.put("message", "预约课程时发生错误: " + e.getMessage());
            System.err.println("Error in BookCourseServlet: " + e.getMessage());
            e.printStackTrace();
        }

        out.print(jsonResponse.toJSONString());
    }
}