package edu.gym.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSON;

import edu.gym.dao.CoachDAO;
import edu.gym.pojo.Coach;

@WebServlet("/SearchCoachesServlet")
public class SearchCoachesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CoachDAO coachDAO;

    @Override
    public void init() throws ServletException {
        coachDAO = new CoachDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        // 权限检查
        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            out.print("{\"error\": \"未授权访问\"}");
            out.flush();
            return;
        }

        try {
            String searchTerm = request.getParameter("searchTerm");
            if (searchTerm == null || searchTerm.trim().isEmpty()) {
                // 如果搜索词为空，返回所有教练
                List<Coach> coaches = coachDAO.getAllCoaches();
                String jsonOutput = JSON.toJSONString(coaches);
                out.print(jsonOutput);
            } else {
                // 搜索教练
                List<Coach> coaches = coachDAO.searchCoaches(searchTerm);
                String jsonOutput = JSON.toJSONString(coaches);
                out.print(jsonOutput);
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"搜索教练失败: " + e.getMessage() + "\"}");
            System.err.println("Error in SearchCoachesServlet: " + e.getMessage());
            e.printStackTrace();
        } finally {
            out.flush();
        }
    }
} 