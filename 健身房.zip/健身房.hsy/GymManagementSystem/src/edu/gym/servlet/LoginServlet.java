package edu.gym.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSONObject;

import edu.gym.dao.UserDAO;
import edu.gym.dao.MemberDAO;
import edu.gym.pojo.User;
import edu.gym.pojo.Member;

@WebServlet("/LoginServlet")  // ע
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO userDAO;
    private MemberDAO memberDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
        memberDAO = new MemberDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("login.html");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");  // �������
        response.setContentType("application/json;charset=UTF-8");  // �޸�����
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JSONObject jsonResponse = new JSONObject();

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (username == null || username.trim().isEmpty() || 
            password == null || password.trim().isEmpty()) {
            jsonResponse.put("success", false);
            jsonResponse.put("message", "用户名和密码不能为空");
            out.print(jsonResponse.toJSONString());
            return;
        }

        try {
            // 首先尝试从User表登录
            User user = userDAO.getUserByUsername(username);
            if (user != null && password.equals(user.getPassword())) {
                // 用户登录成功
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                session.setAttribute("role", user.getRole());
                
                jsonResponse.put("success", true);
                jsonResponse.put("role", user.getRole());
                jsonResponse.put("redirectUrl", user.getRole().equalsIgnoreCase("admin") ? 
                    "admin_dashboard.html" : "member_dashboard.html");
            } else {
                // 如果User表登录失败，尝试从Member表登录
                Member member = memberDAO.getMemberByUsername(username);
                if (member != null && password.equals(member.getPassword())) {
                    // 会员登录成功
                    HttpSession session = request.getSession();
                    session.setAttribute("user", member);
                    session.setAttribute("role", "member");
                    
                    jsonResponse.put("success", true);
                    jsonResponse.put("role", "member");
                    jsonResponse.put("redirectUrl", "member_dashboard.html");
                } else {
                    // 登录失败
                    jsonResponse.put("success", false);
                    jsonResponse.put("message", "用户名或密码错误");
                }
            }
        } catch (Exception e) {
            jsonResponse.put("success", false);
            jsonResponse.put("message", "登录时发生错误: " + e.getMessage());
            System.err.println("Error in LoginServlet: " + e.getMessage());
            e.printStackTrace();
        }

        out.print(jsonResponse.toJSONString());
        out.flush();
    }
}