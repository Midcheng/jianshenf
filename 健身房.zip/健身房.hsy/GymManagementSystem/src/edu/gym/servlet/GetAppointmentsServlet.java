package edu.gym.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSON;

import edu.gym.dao.AppointmentDAO;
import edu.gym.pojo.Appointment;
import edu.gym.pojo.User;
import edu.gym.pojo.Member;
import edu.gym.dao.MemberDAO;

@WebServlet("/GetAppointmentsServlet")
public class GetAppointmentsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private AppointmentDAO appointmentDAO;

    @Override
    public void init() throws ServletException {
        appointmentDAO = new AppointmentDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        // 检查用户是否登录
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"error\": \"未登录或会话已过期\"}");
            return;
        }

        try {
            // 获取会员ID
            Object userObj = session.getAttribute("user");
            int memberId;

            if (userObj instanceof User) {
                // 如果是管理员登录，通过UserID获取会员信息
                User user = (User) userObj;
                Member member = MemberDAO.getMemberByUserId(user.getUserId());
                if (member == null) {
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print("{\"error\": \"未找到会员信息\"}");
                    return;
                }
                memberId = member.getMemberId();
            } else if (userObj instanceof Member) {
                // 如果是会员直接登录，直接使用会员信息
                Member member = (Member) userObj;
                memberId = member.getMemberId();
            } else {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"error\": \"无效的用户类型\"}");
                return;
            }

            // 获取会员的预约列表
            List<Appointment> appointments = appointmentDAO.getMemberAppointments(memberId);
            String jsonOutput = JSON.toJSONStringWithDateFormat(appointments, "yyyy-MM-dd HH:mm:ss");
            out.print(jsonOutput);

        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"获取预约列表时发生错误: " + e.getMessage() + "\"}");
            System.err.println("Error in GetAppointmentsServlet: " + e.getMessage());
            e.printStackTrace();
        }
    }
}