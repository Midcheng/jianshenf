package edu.gym.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSONObject;

import edu.gym.dao.AppointmentDAO;
import edu.gym.dao.CourseDAO;
import edu.gym.pojo.User;
import edu.gym.pojo.Appointment;
import edu.gym.pojo.Member;
import edu.gym.dao.MemberDAO;

@WebServlet("/CancelAppointmentServlet")
public class CancelAppointmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private AppointmentDAO appointmentDAO;
    private CourseDAO courseDAO;

    @Override
    public void init() throws ServletException {
        appointmentDAO = new AppointmentDAO();
        courseDAO = new CourseDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JSONObject jsonResponse = new JSONObject();

        // 检查用户是否登录
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "未登录或会话已过期");
            out.print(jsonResponse.toJSONString());
            return;
        }

        try {
            int appointmentId = Integer.parseInt(request.getParameter("appointmentId"));
            Object userObj = session.getAttribute("user");
            int memberId;

            if (userObj instanceof User) {
                // 如果是管理员登录，通过UserID获取会员信息
                User user = (User) userObj;
                Member member = MemberDAO.getMemberByUserId(user.getUserId());
                if (member == null) {
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    jsonResponse.put("success", false);
                    jsonResponse.put("message", "未找到会员信息");
                    out.print(jsonResponse.toJSONString());
                    return;
                }
                memberId = member.getMemberId();
            } else if (userObj instanceof Member) {
                // 如果是会员直接登录，直接使用会员信息
                Member member = (Member) userObj;
                memberId = member.getMemberId();
            } else {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                jsonResponse.put("success", false);
                jsonResponse.put("message", "无效的用户类型");
                out.print(jsonResponse.toJSONString());
                return;
            }

            // 获取预约信息
            Appointment appointment = appointmentDAO.getAppointmentById(appointmentId);
            if (appointment == null) {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "预约不存在");
                out.print(jsonResponse.toJSONString());
                return;
            }

            // 检查是否是当前会员的预约
            if (appointment.getMemberId() != memberId) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                jsonResponse.put("success", false);
                jsonResponse.put("message", "无权取消此预约");
                out.print(jsonResponse.toJSONString());
                return;
            }

            // 取消预约
            boolean cancelled = appointmentDAO.cancelAppointment(appointmentId, memberId);
            if (cancelled) {
                // 更新课程人数
                courseDAO.updateEnrollment(appointment.getCourseId(), false);
                
                jsonResponse.put("success", true);
                jsonResponse.put("message", "预约已成功取消");
            } else {
                jsonResponse.put("success", false);
                jsonResponse.put("message", "取消预约失败，预约可能已被取消或不存在");
            }

        } catch (NumberFormatException e) {
            jsonResponse.put("success", false);
            jsonResponse.put("message", "无效的预约ID");
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "服务器错误: " + e.getMessage());
            e.printStackTrace();
        }

        out.print(jsonResponse.toJSONString());
    }
}