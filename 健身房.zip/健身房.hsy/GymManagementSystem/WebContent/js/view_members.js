document.addEventListener('DOMContentLoaded', function() {
    loadMembers();
});

const memberTableBody = document.getElementById('memberTableBody');
const messageDiv = document.getElementById('messageDiv');

function loadMembers() {
    memberTableBody.innerHTML = '<tr><td colspan="11" style="text-align: center;">加载中...</td></tr>'; // Show loading state
    messageDiv.style.display = 'none'; // Hide previous messages

    fetch('ViewMembersServlet') // Fetch data from the servlet
        .then(response => {
            if (!response.ok) {
                if (response.status === 403) {
                     throw new Error('权限不足，无法查看会员信息。请以管理员身份登录。');
                }
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(members => {
            populateTable(members);
        })
        .catch(error => {
            console.error('Error loading members:', error);
            memberTableBody.innerHTML = `<tr><td colspan="11" style="text-align: center; color: red;">加载会员信息失败: ${error.message}</td></tr>`;
            showMessage(error.message || '加载会员信息失败', 'error');
        });
}

function populateTable(members) {
    memberTableBody.innerHTML = ''; // Clear loading/error state

    if (!members || members.length === 0) {
        memberTableBody.innerHTML = '<tr><td colspan="11" style="text-align: center;">没有找到会员信息。</td></tr>';
        return;
    }

    members.forEach(member => {
        const row = memberTableBody.insertRow();

        row.insertCell().textContent = member.memberId || '';
        row.insertCell().textContent = member.name || '';
        row.insertCell().textContent = member.gender || '';
        row.insertCell().textContent = member.birthDate || ''; // Assumes date is pre-formatted by servlet
        row.insertCell().textContent = member.phoneNumber || '';
        row.insertCell().textContent = member.email || '';
        row.insertCell().textContent = member.registrationDate || ''; // Assumes date is pre-formatted
        row.insertCell().textContent = member.membershipLevel || '';
        row.insertCell().textContent = member.status || '';
        row.insertCell().textContent = member.emergencyContact || '';

        // Action cell (Delete button)
        const actionCell = row.insertCell();
        actionCell.style.textAlign = 'center';
        const deleteButton = document.createElement('button');
        deleteButton.textContent = '删除';
        deleteButton.classList.add('action-button', 'delete-button');
        deleteButton.dataset.memberId = member.memberId; // Store memberId in data attribute
        deleteButton.addEventListener('click', handleDelete);
        actionCell.appendChild(deleteButton);
    });
}

function handleDelete(event) {
    const button = event.target;
    const memberId = button.dataset.memberId;
    const memberName = button.closest('tr').cells[1].textContent; // Get name from the row

    if (!confirm(`确定要删除会员 "${memberName}" (ID: ${memberId}) 吗？`)) {
        return; // User cancelled
    }

    // Disable button while processing
    button.disabled = true;
    button.textContent = '删除中...';
    messageDiv.style.display = 'none'; // Hide previous messages

    const formData = new URLSearchParams();
    formData.append('memberId', memberId);

    fetch('DeleteMemberServlet', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData
    })
    .then(response => response.json().then(data => ({ status: response.status, body: data }))) // Process response status and body
    .then(({ status, body }) => {
        if (body.success) {
            // Remove the row from the table
            button.closest('tr').remove();
            showMessage(body.message || '会员删除成功', 'success');
             // Optional: Reload all members if counts or pagination were involved
             // loadMembers();
        } else {
            throw new Error(body.message || `删除失败 (HTTP ${status})`);
        }
    })
    .catch(error => {
        console.error('Error deleting member:', error);
        showMessage(`删除会员失败: ${error.message}`, 'error');
        // Re-enable button after error
        button.disabled = false;
        button.textContent = '删除';
    });
}

function showMessage(message, type = 'info') {
    messageDiv.textContent = message;
    messageDiv.className = `message ${type}`; // Set class for styling (success, error, info)
    messageDiv.style.display = 'block';

    // Optional: Hide message after a few seconds
    /*
    setTimeout(() => {
        messageDiv.style.display = 'none';
    }, 5000); // Hide after 5 seconds
    */
}
