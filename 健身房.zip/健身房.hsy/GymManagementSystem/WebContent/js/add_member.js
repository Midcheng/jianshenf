const addMemberForm = document.getElementById('addMemberForm');
const messageDiv = document.getElementById('messageDiv');
const submitButton = addMemberForm.querySelector('button[type="submit"]');

addMemberForm.addEventListener('submit', function(event) {
    event.preventDefault(); // 阻止表单默认提交行为
    messageDiv.style.display = 'none'; // 隐藏之前的消息
    submitButton.disabled = true; // 禁用按钮防止重复提交
    submitButton.textContent = '正在添加...';

    // 客户端验证
    const nameInput = document.getElementById('name');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const statusInput = document.getElementById('status');

    if (!nameInput.value.trim()) {
        showMessage('会员姓名不能为空。', 'error');
        submitButton.disabled = false;
        submitButton.textContent = '添加会员';
        nameInput.focus();
        return;
    }

    if (!usernameInput.value.trim()) {
        showMessage('账号不能为空。', 'error');
        submitButton.disabled = false;
        submitButton.textContent = '添加会员';
        usernameInput.focus();
        return;
    }

    if (!passwordInput.value.trim()) {
        showMessage('密码不能为空。', 'error');
        submitButton.disabled = false;
        submitButton.textContent = '添加会员';
        passwordInput.focus();
        return;
    }

    if (passwordInput.value.length < 6) {
        showMessage('密码长度不能少于6位。', 'error');
        submitButton.disabled = false;
        submitButton.textContent = '添加会员';
        passwordInput.focus();
        return;
    }

    if (!statusInput.value.trim()) {
        showMessage('会员状态不能为空。', 'error');
        submitButton.disabled = false;
        submitButton.textContent = '添加会员';
        statusInput.focus();
        return;
    }

    // 可以添加更多客户端验证...
    // --- 验证结束 ---


    // 使用 FormData 来收集表单数据，能正确处理各种类型的输入
    const formData = new FormData(addMemberForm);

    // 使用 fetch 发送 POST 请求
    fetch('AddMemberServlet', {
        method: 'POST',
        body: new URLSearchParams(formData) // 将 FormData 转换为 URLSearchParams 格式
        // 注意：如果发送 JSON，需要设置 headers: {'Content-Type': 'application/json'},
        // 并在 servlet 中相应地解析 JSON。但这里我们使用标准表单提交。
    })
    .then(response => response.json().then(data => ({ ok: response.ok, status: response.status, body: data })))
    .then(({ ok, status, body }) => {
        if (ok && body.success) {
            showMessage(body.message || '会员添加成功！', 'success');
            addMemberForm.reset(); // 清空表单
            // 可以选择跳转回会员列表页面
            // setTimeout(() => { window.location.href = 'view_members.html'; }, 2000);
        } else {
            // 从响应体中获取错误消息，如果没有则提供通用消息
            throw new Error(body.message || `添加失败 (HTTP ${status})`);
        }
    })
    .catch(error => {
        console.error('Error adding member:', error);
        showMessage(`添加会员失败: ${error.message}`, 'error');
    })
    .finally(() => {
        // 无论成功或失败，重新启用按钮
        submitButton.disabled = false;
        submitButton.textContent = '添加会员';
    });
});

// 用于显示消息的辅助函数 (和 view_members.js 中的类似)
function showMessage(message, type = 'info') {
    messageDiv.textContent = message;
    messageDiv.className = `message ${type}`; // 设置样式类 (success, error, info)
    messageDiv.style.display = 'block'; // 显示消息区域
     // 滚动到消息区域使其可见 (如果页面较长)
     messageDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// 页面加载时可以预填注册日期为今天 (可选)
/*
document.addEventListener('DOMContentLoaded', function() {
    const registrationDateInput = document.getElementById('registrationDate');
    if (registrationDateInput && !registrationDateInput.value) {
        const today = new Date().toISOString().split('T')[0]; // 获取 YYYY-MM-DD 格式的今天日期
        registrationDateInput.value = today;
    }
});
*/