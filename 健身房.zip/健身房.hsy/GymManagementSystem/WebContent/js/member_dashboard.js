// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    loadProfile();
    loadCourses();
    loadAppointments();
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                searchCourses();
            }
        });
    }
});

// 加载会员信息
function loadProfile() {
    fetch('GetMemberProfileServlet')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            document.getElementById('memberId').textContent = data.memberId || '';
            document.getElementById('profileName').textContent = data.name || '';
            document.getElementById('gender').textContent = data.gender || '';
            document.getElementById('phone').textContent = data.phoneNumber || '';
            document.getElementById('email').textContent = data.email || '';
            document.getElementById('membershipLevel').textContent = data.membershipLevel || '';
            document.getElementById('registrationDate').textContent = formatDateTime(data.registrationDate);
            document.getElementById('memberStatus').textContent = data.status || '';
        })
        .catch(error => {
            console.error('Error loading profile:', error);
            showMessage('profileMessage', '加载个人信息失败: ' + error.message, 'error');
        });
}

// 加载课程列表
function loadCourses() {
    fetch('GetCoursesServlet')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(courses => {
            const courseList = document.getElementById('courseTableBody');
            courseList.innerHTML = '';

            courses.forEach(course => {
                const row = `
                    <tr>
                        <td>${course.courseName || ''}</td>
                        <td>${course.coachName || ''}</td>
                        <td>${formatDateTime(course.courseTime)}</td>
                        <td>${course.location || ''}</td>
                        <td>${course.capacity - course.currentEnrollment}</td>
                        <td>
                            <button class="btn btn-primary" 
                                    onclick="bookCourse(${course.courseId})"
                                    ${course.currentEnrollment >= course.capacity ? 'disabled' : ''}>
                                ${course.currentEnrollment >= course.capacity ? '已满' : '预约'}
                            </button>
                        </td>
                    </tr>
                `;
                courseList.innerHTML += row;
            });
        })
        .catch(error => {
            console.error('Error loading courses:', error);
            showMessage('courseMessage', '加载课程列表失败: ' + error.message, 'error');
        });
}

// 搜索课程
function searchCourses() {
    const searchTerm = document.getElementById('courseSearch').value.trim();
    fetch(`GetCoursesServlet?search=${encodeURIComponent(searchTerm)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(courses => {
            const courseList = document.getElementById('courseTableBody');
            courseList.innerHTML = '';

            if (courses.length === 0) {
                courseList.innerHTML = '<tr><td colspan="6">没有找到符合条件的课程</td></tr>';
                return;
            }

            courses.forEach(course => {
                const row = `
                    <tr>
                        <td>${course.courseName || ''}</td>
                        <td>${course.coachName || ''}</td>
                        <td>${formatDateTime(course.courseTime)}</td>
                        <td>${course.location || ''}</td>
                        <td>${course.capacity - course.currentEnrollment}</td>
                        <td>
                            <button class="btn btn-primary" 
                                    onclick="bookCourse(${course.courseId})"
                                    ${course.currentEnrollment >= course.capacity ? 'disabled' : ''}>
                                ${course.currentEnrollment >= course.capacity ? '已满' : '预约'}
                            </button>
                        </td>
                    </tr>
                `;
                courseList.innerHTML += row;
            });
        })
        .catch(error => {
            console.error('Error searching courses:', error);
            showMessage('courseMessage', '搜索课程失败: ' + error.message, 'error');
        });
}

// 重置搜索
function resetSearch() {
    document.getElementById('searchInput').value = '';
    document.getElementById('searchType').value = 'all';
    loadCourses();
}

// 加载预约列表
function loadAppointments() {
    fetch('GetAppointmentsServlet')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(appointments => {
            const appointmentList = document.getElementById('appointmentList');
            appointmentList.innerHTML = '';

            if (appointments.length === 0) {
                appointmentList.innerHTML = '<p>暂无预约记录</p>';
                return;
            }

            appointments.forEach(appointment => {
                const appointmentElement = document.createElement('div');
                appointmentElement.className = 'appointment-item';
                appointmentElement.innerHTML = `
                    <h3>${appointment.courseName}</h3>
                    <p>教练: ${appointment.coachName}</p>
                    <p>时间: ${formatDateTime(appointment.courseTime)}</p>
                    <p>地点: ${appointment.location}</p>
                    <p>状态: ${appointment.status}</p>
                    ${appointment.status === 'Active' ? 
                        `<button onclick="cancelAppointment(${appointment.appointmentId})">取消预约</button>` : 
                        ''}
                `;
                appointmentList.appendChild(appointmentElement);
            });
        })
        .catch(error => {
            console.error('Error loading appointments:', error);
            showMessage('appointmentMessage', '加载预约列表失败: ' + error.message, 'error');
        });
}

// 预约课程
function bookCourse(courseId) {
    const formData = new URLSearchParams();
    formData.append('courseId', courseId);

    fetch('BookCourseServlet', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showMessage('courseMessage', data.message, 'success');
            loadCourses(); // 重新加载课程列表
            loadAppointments(); // 重新加载预约列表
        } else {
            throw new Error(data.message || '预约失败');
        }
    })
    .catch(error => {
        console.error('Error booking course:', error);
        showMessage('courseMessage', '预约课程失败: ' + error.message, 'error');
    });
}

// 取消预约
function cancelAppointment(appointmentId) {
    if (!confirm('确定要取消这个预约吗？')) {
        return;
    }

    const formData = new URLSearchParams();
    formData.append('appointmentId', appointmentId);

    // 添加重试机制
    const maxRetries = 3;
    let retryCount = 0;

    function attemptCancel() {
        fetch('CancelAppointmentServlet', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest' // 添加请求头以标识AJAX请求
            },
            body: formData,
            credentials: 'same-origin' // 确保发送cookies
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                showMessage('appointmentMessage', data.message, 'success');
                // 立即刷新预约列表
                loadAppointments();
                // 刷新课程列表
                loadCourses();
            } else {
                throw new Error(data.message || '取消预约失败');
            }
        })
        .catch(error => {
            console.error('Error canceling appointment:', error);
            
            // 如果是网络错误且未超过重试次数，则重试
            if (error.name === 'TypeError' && retryCount < maxRetries) {
                retryCount++;
                console.log(`Retrying cancel appointment (${retryCount}/${maxRetries})...`);
                setTimeout(attemptCancel, 1000 * retryCount); // 递增延迟
                return;
            }

            // 显示错误消息
            let errorMessage = '取消预约失败: ';
            if (error.name === 'TypeError') {
                errorMessage += '网络连接错误，请检查网络连接或禁用广告拦截器后重试';
            } else {
                errorMessage += error.message;
            }
            showMessage('appointmentMessage', errorMessage, 'error');
        });
    }

    // 开始第一次尝试
    attemptCancel();
}

// 格式化日期时间
function formatDateTime(dateTimeStr) {
    if (!dateTimeStr) return '';
    const date = new Date(dateTimeStr);
    return date.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// 显示消息
function showMessage(elementId, message, type) {
    const messageElement = document.getElementById(elementId);
    if (messageElement) {
        messageElement.textContent = message;
        messageElement.className = `message ${type}`;
        messageElement.style.display = 'block';
        setTimeout(() => {
            messageElement.style.display = 'none';
        }, 5000);
    }
} 