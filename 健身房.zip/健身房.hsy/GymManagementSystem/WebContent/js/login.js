document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessageDiv = document.getElementById('errorMessage');
    errorMessageDiv.textContent = '';

    if (!username || !password) {
        errorMessageDiv.textContent = '用户名和密码不能为空';
        return;
    }

    const formData = new URLSearchParams();
    formData.append('username', username);
    formData.append('password', password);

    // 禁用提交按钮，防止重复提交
    const submitButton = this.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    submitButton.textContent = '登录中...';

    fetch('LoginServlet', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('登录成功，角色:', data.role); // 调试信息
            console.log('重定向至:', data.redirectUrl || 'admin_dashboard.html');
            
            // 使用服务器指定的重定向地址或默认路径
            window.location.href = data.redirectUrl || 'admin_dashboard.html';
        } else {
            errorMessageDiv.textContent = data.message || '登录失败';
            submitButton.disabled = false;
            submitButton.textContent = '登录';
        }
    })
    .catch(error => {
        console.error('登录错误:', error);
        errorMessageDiv.textContent = '登录请求失败，请稍后重试';
        submitButton.disabled = false;
        submitButton.textContent = '登录';
    });
});